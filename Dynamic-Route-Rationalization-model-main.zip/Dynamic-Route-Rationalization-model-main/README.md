# Dynamic-Route-Rationalization-model
Problem Statement:- Dynamic route rationalization model based on machine learning/AI would be required based on real-time traffic and road parameters.
<br>
PS CODE:- SIH1617 
